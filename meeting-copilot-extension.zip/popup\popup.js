const $ = (id) => document.getElementById(id);

const send = (message) =>
  new Promise((resolve) => chrome.runtime.sendMessage(message, (r) => resolve(r || {})));

async function load() {
  const { config } = await send({ type: 'getConfig' });
  if (!config) return;
  $('link').value = config.activeMeeting?.link || '';
  $('title').value = config.activeMeeting?.title || '';
  $('context').value = config.activeMeeting?.context || '';
  $('autoAnswer').checked = Boolean(config.autoAnswer);
  $('autoSend').checked = Boolean(config.autoSend);
}

function showStatus(text, isError) {
  const el = $('status');
  el.textContent = text;
  el.className = 'status' + (isError ? ' error' : '');
}

async function save() {
  const link = $('link').value.trim();
  const patch = {
    activeMeeting: link
      ? { link, title: $('title').value.trim(), context: $('context').value.trim() }
      : null,
    autoAnswer: $('autoAnswer').checked,
    autoSend: $('autoSend').checked,
  };
  const resp = await send({ type: 'setConfig', patch });
  if (resp.ok) showStatus('Saved. Open or refresh the meeting tab.');
  else showStatus(resp.error || 'Could not save.', true);
}

$('save').addEventListener('click', save);
$('openOptions').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

load();
