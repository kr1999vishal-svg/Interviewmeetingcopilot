/**
 * Orchestrator content script.
 *
 * - Loads config (active meeting link, AI creds via background).
 * - Gates activation so the overlay only runs on the meeting whose link was set.
 * - Polls captions, finalises lines, detects questions.
 * - Requests AI answers (via background -> backend) and optionally writes them
 *   into the meeting chat.
 */
(function () {
  const NS = window.MeetingCopilot;
  const { platform, overlay } = NS;
  if (!platform || platform.detect() === null) return;

  const POLL_MS = 1500;
  const MAX_CONTEXT_LINES = 12;
  const QUESTION_RE =
    /\b(what|why|how|when|where|who|which|whose|whom|can|could|would|should|do|does|did|is|are|am|was|were|will|may|might|have|has)\b/i;

  let config = null;
  let active = false;
  let prevTexts = [];
  const processed = new Set();
  const contextLines = [];
  let lastQuestion = '';
  let currentAnswer = '';
  let answering = false;
  let debugOn = false;
  let lastCaptionCount = 0;
  let processingAllowed = false;
  let listening = false; // private tab-audio transcription

  /* -------------------------- messaging helpers -------------------------- */
  const send = (message) =>
    new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (resp) => resolve(resp || { ok: false }));
    });

  async function loadConfig() {
    const resp = await send({ type: 'getConfig' });
    config = resp.config || {};
    return config;
  }

  /* ----------------------------- URL gating ------------------------------ */
  function tokenFromLink(link) {
    if (!link) return '';
    try {
      const decoded = decodeURIComponent(link);
      const meet = decoded.match(/meet\.google\.com\/([a-z0-9\-]+)/i);
      if (meet) return meet[1].toLowerCase();
      const teams = decoded.match(/meeting_[A-Za-z0-9]+/);
      if (teams) return teams[0].toLowerCase();
      const thread = decoded.match(/19:[^/@]+@thread\.v2/);
      if (thread) return thread[0].toLowerCase();
    } catch {
      /* ignore */
    }
    return '';
  }

  function matchesActiveMeeting() {
    const link = config?.activeMeeting?.link;
    if (!link) return { ok: true, reason: 'no-link' }; // no restriction configured
    const token = tokenFromLink(link);
    if (!token) return { ok: true, reason: 'untokenizable' };
    const href = decodeURIComponent(location.href).toLowerCase();
    return { ok: href.includes(token), reason: token };
  }

  /* --------------------------- caption polling --------------------------- */
  function isQuestion(text) {
    const t = text.trim();
    if (t.length < 6) return false;
    if (t.endsWith('?')) return true;
    return QUESTION_RE.test(t.split(/\s+/).slice(0, 3).join(' '));
  }

  function recentContext() {
    return contextLines.slice(-MAX_CONTEXT_LINES).join('\n');
  }

  async function answerQuestion(question, { auto } = {}) {
    if (!question || answering) return;
    answering = true;
    lastQuestion = question;
    overlay.setQuestion(question);
    overlay.setAnswer('Thinking…', true);
    const resp = await send({
      type: 'answer',
      payload: { question, transcript: recentContext() },
    });
    answering = false;
    if (resp.ok && resp.answer) {
      currentAnswer = resp.answer;
      overlay.setAnswer(currentAnswer, false);
      if (auto && config?.autoAnswer) {
        await platform.insertChatText(currentAnswer);
        if (config?.autoSend) await platform.sendChat();
      }
    } else {
      overlay.setAnswer('⚠ ' + (resp.error || 'Could not get an answer.'), false);
    }
  }

  function onFinalLine(line) {
    contextLines.push(`${line.speaker}: ${line.text}`);
    overlay.setTranscript(`${line.speaker}: ${line.text}`);
    // Only assist the meeting whose link was configured (requirement #4).
    if (!processingAllowed) return;
    if (isQuestion(line.text) && line.text !== lastQuestion) {
      answerQuestion(line.text, { auto: true });
    }
  }

  function renderDebug() {
    const match = matchesActiveMeeting();
    overlay.setDebug({
      platform: platform.detect() || 'unknown',
      'captions found': lastCaptionCount,
      'chat input': platform.hasChatInput() ? 'yes' : 'no',
      'lines processed': processed.size,
      'auto-answer': config?.autoAnswer ? 'on' : 'off',
      'gate token': match.reason,
      'gate match': match.ok ? 'yes' : 'no',
      url: location.href.slice(0, 80),
    });
  }

  function pollCaptions() {
    const lines = platform.getCaptionLines();
    lastCaptionCount = lines.length;
    if (debugOn) renderDebug();
    if (lines.length) {
      const texts = lines.map((l) => l.text);
      // A line is "final" once it has been identical for one poll cycle.
      for (const line of lines) {
        if (processed.has(line.text)) continue;
        if (prevTexts.includes(line.text)) {
          processed.add(line.text);
          onFinalLine(line);
        }
      }
      prevTexts = texts;
      // Always reflect the very latest (possibly in-progress) line.
      const last = lines[lines.length - 1];
      if (last && !answering) overlay.setTranscript(`${last.speaker}: ${last.text}`);
    }
  }

  /* ------------------------------ lifecycle ------------------------------ */
  function activate() {
    if (active) return;
    active = true;
    overlay.mount();
    overlay.setAuto(Boolean(config?.autoAnswer));
    overlay.setMeetingTitle(config?.activeMeeting?.title || 'Meeting Copilot');

    overlay.on('answer', () => {
      const q = lastQuestion || contextLines[contextLines.length - 1] || '';
      answerQuestion(q, { auto: false });
    });
    overlay.on('insert', async () => {
      if (currentAnswer) await platform.insertChatText(currentAnswer);
    });
    overlay.on('send', async () => {
      if (!currentAnswer) return;
      await platform.insertChatText(currentAnswer);
      await platform.sendChat();
    });
    overlay.on('toggleAuto', async () => {
      const next = !config.autoAnswer;
      const resp = await send({ type: 'setConfig', patch: { autoAnswer: next } });
      config = resp.config || { ...config, autoAnswer: next };
      overlay.setAuto(Boolean(config.autoAnswer));
    });
    overlay.on('toggleDebug', () => {
      debugOn = !debugOn;
      overlay.setDebugVisible(debugOn);
      if (debugOn) renderDebug();
    });
    overlay.on('toggleListen', async () => {
      if (listening) {
        await send({ type: 'stopCapture' });
        listening = false;
        overlay.setListening(false);
        overlay.setStatus('Private transcription stopped.', 'ok');
      } else {
        const resp = await send({ type: 'startCapture' });
        if (resp.ok) {
          listening = true;
          overlay.setListening(true);
          overlay.setStatus('Starting private transcription…', 'ok');
        } else {
          overlay.setStatus('⚠ ' + (resp.error || 'Failed to start capture'), 'warn');
        }
      }
    });

    updateGateStatus();
  }

  /** Recompute whether AI assistance is allowed and reflect it in the overlay. */
  function updateGateStatus() {
    const match = matchesActiveMeeting();
    processingAllowed = match.ok;
    overlay.setMeetingTitle(config?.activeMeeting?.title || 'Meeting Copilot');
    overlay.setAuto(Boolean(config?.autoAnswer));
    if (match.reason === 'no-link') {
      overlay.setStatus('No active meeting set — open the extension popup.', 'warn');
    } else if (!match.ok) {
      overlay.setStatus('Not the configured meeting — assistance paused.', 'warn');
    } else {
      overlay.setStatus('Listening to captions…', 'ok');
    }
  }

  function deactivate() {
    if (!active) return;
    active = false;
    overlay.destroy();
  }

  async function evaluateGate() {
    await loadConfig();
    if (config?.enabled === false) return deactivate();
    // Always show the overlay on a meeting page; gating only controls whether
    // AI assistance runs, so diagnostics remain available either way.
    activate();
    updateGateStatus();
  }

  // React to config changes (e.g., user sets the active meeting in the popup).
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.config) {
      config = changes.config.newValue;
      evaluateGate();
    }
  });

  // Handle STT transcripts, errors, and status from the background script.
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'sttTranscript') {
      contextLines.push(`Private: ${message.text}`);
      overlay.setTranscript(`Private: ${message.text}`);
      if (debugOn) renderDebug();
    } else if (message.type === 'sttError') {
      listening = false;
      overlay.setListening(false);
      overlay.setStatus('⚠ Transcription error: ' + message.error, 'warn');
    } else if (message.type === 'sttStatus') {
      if (message.status === 'listening') {
        overlay.setStatus('Privately transcribing meeting audio…', 'ok');
      } else if (message.status === 'idle') {
        overlay.setStatus('Private transcription idle.', 'ok');
      }
    }
  });

  // Initial start + periodic re-evaluation (SPA navigation, late captions).
  evaluateGate();
  setInterval(() => {
    if (active) pollCaptions();
    else evaluateGate();
  }, POLL_MS);

  // Also re-check gating on SPA URL changes.
  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      evaluateGate();
    }
  }, 2000);
})();
