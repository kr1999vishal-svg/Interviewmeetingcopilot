const $ = (id) => document.getElementById(id);

const send = (message) =>
  new Promise((resolve) => chrome.runtime.sendMessage(message, (r) => resolve(r || {})));

function showStatus(text, isError) {
  const el = $('status');
  el.textContent = text;
  el.className = 'status' + (isError ? ' error' : '');
}

async function load() {
  const { config } = await send({ type: 'getConfig' });
  if (!config) return;
  $('backendUrl').value = config.backendUrl || 'http://localhost:4000';
  $('aiProvider').value = config.aiProvider || 'openai';
  $('aiApiKey').value = config.aiApiKey || '';
  $('aiModel').value = config.aiModel || '';
  $('enabled').checked = config.enabled !== false;
}

async function save() {
  const patch = {
    backendUrl: $('backendUrl').value.trim() || 'http://localhost:4000',
    aiProvider: $('aiProvider').value,
    aiApiKey: $('aiApiKey').value.trim(),
    aiModel: $('aiModel').value.trim(),
    enabled: $('enabled').checked,
  };
  const resp = await send({ type: 'setConfig', patch });
  if (resp.ok) showStatus('Settings saved.');
  else showStatus(resp.error || 'Could not save settings.', true);
}

async function test() {
  showStatus('Testing…');
  const backendUrl = ($('backendUrl').value.trim() || 'http://localhost:4000').replace(/\/$/, '');
  const body = {
    provider: $('aiProvider').value,
    apiKey: $('aiApiKey').value.trim(),
    model: $('aiModel').value.trim() || undefined,
  };
  try {
    const res = await fetch(`${backendUrl}/api/ai/test`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (data.ok) showStatus(`Connected ✓ ${data.model ? '(' + data.model + ')' : ''}`);
    else showStatus(data.message || 'Connection failed.', true);
  } catch (err) {
    showStatus(`Could not reach backend at ${backendUrl}. Is it running?`, true);
  }
}

$('save').addEventListener('click', save);
$('test').addEventListener('click', test);
load();
